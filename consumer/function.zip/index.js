exports.handler = function(event, context) {
    // event.Records.forEach(function(record) {
    //     console.log('record: ', record);
    //     const payload = Buffer.from(record.kinesis.data, 'base64').toString('ascii');
    //     console.log('Decoded payload:', payload);
    // });
    console.log(`event = ${JSON.stringify(event)}`);
    console.log(`context = ${JSON.stringify(context)}`);

    return `Hello World!`;
};
